#include "ofApp.h"

int main()
{
	ofSetupOpenGL(340,130,OF_WINDOW);
	ofRunApp(new ofApp());
}
