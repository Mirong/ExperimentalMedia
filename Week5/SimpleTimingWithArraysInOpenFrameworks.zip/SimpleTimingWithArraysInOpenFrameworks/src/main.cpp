#include "ofApp.h"

int main()
{
	ofSetupOpenGL(340,120,OF_WINDOW);
	ofRunApp(new ofApp());
}
